const express = require('express');
const fs = require('fs'); 
const app = express();
const port = 3000;
const path = './alumno.json';

const BodyParser = require('body-parser');
app.use(BodyParser.json());
app.use(BodyParser.urlencoded({ extended: false }));

app.listen(port, () => {
    console.log('Servidor Web de la Tarea 1.');
});

app.get('/alumno', (req, res) => {
    fs.readFile(path, (err, data) => {
        if (err) {
            res.sendStatus(500);
        } else {
         const alumno = JSON.parse(data);
            res.send(alumno);
        }
    });
});  

app.post('/alumno', (req, res) => {
    const contenido = req.body;
   fs.readFile
    (path, (err, data) => {
        if (err) {
            res.sendStatus(500);
        } else {
            const alumnos = JSON.parse(data);
            alumnos.push(contenido);
            fs.writeFile(path, JSON.stringify(alumnos), (err) => {
                if (err) {
                    res.sendStatus(500);
                } else {
                    res.sendStatus(alumnos);
                }
            });
        }
    });         
}
);