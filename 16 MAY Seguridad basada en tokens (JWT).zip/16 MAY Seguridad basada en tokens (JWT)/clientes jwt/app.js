const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs'); // sistema de archivos
const jwt = require('jsonwebtoken'); // seguridad con tokens

const app = express();
const puerto = 3000;
const path = './clientes.json';
const secretKey = 'supersecreto'; // clave para firmar los tokens

app.use(bodyParser.json());

// Iniciar servidor
app.listen(puerto, () => {
    console.log('Servidor web iniciado.');
});

// **Endpoint de autenticación (login)**
app.post('/login', (req, res) => {
    const { usuario, password } = req.body;
    
    // Simulación de autenticación
    if (usuario === 'admin' && password === '123') {
        const token = jwt.sign({ usuario }, secretKey, { expiresIn: '1h' });
        res.json({ token });
    } else {
        res.status(401).json({ mensaje: 'Credenciales incorrectas' });
    }
});

// **Middleware para verificar token**
function verificarToken(req, res, next) {
    const header = req.headers['authorization'] || '';
    const token = header.split(' ')[1];

    if (!token) {
        return res.status(401).json({ mensaje: 'Token no proporcionado' });
    }

    try {
        const payload = jwt.verify(token, secretKey);
        req.usuario = payload.usuario; // Guardar usuario del token
        next();
    } catch (error) {
        res.status(401).json({ mensaje: 'Token inválido' });
    }
}

// **Rutas protegidas con JWT**
app.get('/clientes', verificarToken, (req, res) => {
    fs.readFile(path, (err, data) => {
        if (err) {
            res.sendStatus(500);
        } else {
            res.json(JSON.parse(data));
        }
    });
});

app.post('/clientes', verificarToken, (req, res) => {
    const contenido = req.body;

    fs.readFile(path, (err, data) => {
        if (err) {
            res.sendStatus(500);
        } else {
            const clientes = JSON.parse(data);
            clientes.push(contenido);

            fs.writeFile(path, JSON.stringify(clientes), (err) => {
                if (err) {
                    res.sendStatus(500);
                }
                res.json(clientes);
            });
        }
    });
});

