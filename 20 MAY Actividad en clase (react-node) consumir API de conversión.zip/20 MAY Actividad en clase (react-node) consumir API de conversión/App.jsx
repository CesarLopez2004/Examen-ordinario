import { useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [monedas, setMonedas] = useState([])
  useEffect(() => { //SE ejecuta la primera vez.
fetch('http://localhost:3000/monedas')
  .then((res) => {
  return res.json() ;
  })
  .then((data) => {
    console.log(data);
    setMonedas(data);
  })
  }
  , [])

  return (
    <>
    <h1>Informacion de Monedas</h1>
  <table>
    <thead>
      <tr>
        <th> ID </th>
        <th> Origen </th>
        <th> Destino </th>
        <th> Valor </th>
      </tr>
    </thead>
    <tbody>
      {monedas.map((moneda, index) => (
        <tr key={index}>
          <td>{moneda.id}</td>
          <td>{moneda.origen}</td>
          <td>{moneda.destino}</td>
          <td>{moneda.valor}</td>
        </tr>
      ))}
    </tbody>
  </table>
    </>
  )
}

export default App
