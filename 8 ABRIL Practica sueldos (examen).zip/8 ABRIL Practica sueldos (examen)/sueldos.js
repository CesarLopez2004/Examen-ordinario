const { DataTypes } = require('sequelize');
const sequelite = require ('../conexion') //objeto que representa la conexion a la bd

const sueldos = sequelite.define('sueldo',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    tipo: {
        type: DataTypes.STRING
    },
    sueldoDiario: {
        type: DataTypes.DOUBLE
    },
    bonoMensual: {
        type: DataTypes.DOUBLE
    }
},{
    timestamps: false
})

module.exports = sueldos;

