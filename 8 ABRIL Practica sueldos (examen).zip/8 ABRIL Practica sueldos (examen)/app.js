const express = require('express')
const bodyParser = require('body-parser')
const sueldos = require('./models/sueldos')
const { where } = require('sequelize')
const app = express()
const puerto = 3000

app.use(bodyParser.json())

app.listen(puerto, () =>{
    console.log('servidor iniciado')
})

app.post('/sueldos/cacular',async (req,res) => {
    const  {tipo, dias} = req.body;
    const data = sueldos.findOne({
        where: {
            tipo
        }
    })
    let {sueldoDiario, bonoMensual} = data;
    if (bonoMensual < 25){
        bonoMensual = 0;
    }
    const total = sueldoDiario * dias + bonoMensual;
    res.send({
        tipo, dias, sueldoDiario, bonoMensual, total
    })
})