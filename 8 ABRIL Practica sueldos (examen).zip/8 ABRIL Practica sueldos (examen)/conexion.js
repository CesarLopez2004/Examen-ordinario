const { Sequelize } = require ('sequelize') //importar sequelize   

//crear un objeto de sequelite para la conexion a la bd
const sequelite = new Sequelize ({
    dialect: 'sqlite',
    storage: './sueldo.sqlite' //nombre del archivo de bd
})

module.exports = sequelite;