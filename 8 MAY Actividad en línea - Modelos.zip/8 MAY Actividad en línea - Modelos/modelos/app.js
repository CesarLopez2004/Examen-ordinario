const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const puerto = 3000; 
const sequelize = require('./conexion.js');
const modelos = require('./models/modelos.js');


app.use(bodyParser.json());


sequelize.sync()
    .then(() => {
        console.log('Base de datos sincronizada correctamente');
    })
    .catch(err => {
        console.error('Error al sincronizar la base de datos:', err);
    });

app.get('/', (req, res) => {
    res.send('¡Bienvenido a la API!');
});

app.listen(puerto, () => {
    console.log('Servidor escuchando en el puerto ');
});
