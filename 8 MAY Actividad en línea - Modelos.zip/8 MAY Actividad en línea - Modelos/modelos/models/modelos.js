const {DataTypes} = require('sequelize');
const sequelize = require('../conexion.js');
const cliente = sequelize.define('cliente',
    {
        id:{
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        nombre:{
            type: DataTypes.STRING,
        },
        correo:{
            type: DataTypes.STRING,
        },
        telefono:{
            type: DataTypes.STRING,
        },
        direccion:{
            type: DataTypes.STRING,
        }
    }
);

const proveedores = sequelize.define('proveedores',
    {
        id:{
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        nombre:{
            type: DataTypes.STRING,
        },
        direccion:{
            type: DataTypes.STRING,
        }
    }
);

const articulos = sequelize.define('articulos',
    {
        id:{
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        descripcion:{
            type: DataTypes.STRING,
        },
        precio:{
            type: DataTypes.FLOAT,
        },
        existencia:{
            type: DataTypes.INTEGER,
        },
    }
);

const empleados = sequelize.define('empleados',
    {
        id:{
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        nombre:{
            type: DataTypes.STRING,
        },
        telefono:{
            type: DataTypes.STRING,
        },
        fecha_de_nacimiento:{
            type: DataTypes.DATE,
        },
        sueldo:{
            type: DataTypes.FLOAT,
        },
    }
);

module.exports = {
    cliente,
    proveedores,
    articulos,
    empleados
};