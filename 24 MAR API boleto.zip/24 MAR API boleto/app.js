const express = require('express');
const app = express();
const puerto = 3000;

// Crear servidor
app.listen(puerto, () => {
    console.log('servidor web iniciado');
});

// Ruta
app.get('/coste/:seccion/:cantidad/:dia', (req, res) => {
    const { seccion, cantidad, dia } = req.params;

    // Validaciones
    if (seccion !== 'A' && seccion !== 'B' && seccion !== 'C' && seccion !== 'D') {
        res.sendStatus(400); // Sección incorrecta
        return;
    }

    if (cantidad <= 0) {
        res.sendStatus(400); // Cantidad inválida
        return;
    }

    let precioBase = 0;
    let descuento = 0;
    let precioTotal = 0;

    // Precio base según la sección
    switch (seccion) {
        case 'A':
            precioBase = 300;
            break;
        case 'B':
            precioBase = 490;
            break;
        case 'C':
            precioBase = 670;
            break;
        case 'D':
            precioBase = 899;
            break;
    }

    // Cálculo del precio total inicial
    precioTotal = precioBase * cantidad;

    // Descuento del 5% si se compran más de un boleto
    if (cantidad > 1) {
        descuento += precioTotal * 0.05;
    }

    // Descuento del 16% si el día es domingo
    if (dia === 'domingo') {
        descuento += precioTotal * 0.16;
    }

    // Aplicar descuentos al precio total
    precioTotal -= descuento;

    // Respuesta con los datos calculados
    const data = {
        seccion,
        cantidad: parseInt(cantidad),
        dia,
        precioBase,
        descuento,
        precioTotal
    };

    res.send(data);
});
