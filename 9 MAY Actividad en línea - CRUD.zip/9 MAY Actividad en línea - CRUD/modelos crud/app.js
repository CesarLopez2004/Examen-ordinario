const express = require('express');
const bodyParser = require('body-parser');
const sequelize = require('./conexion');
const { cliente, proveedores, articulos, empleados } = require('./models/modelos');

const app = express();
const puerto = 3000;

app.use(bodyParser.json());

// 📌 Sincronizar la base de datos antes de iniciar el servidor
sequelize.sync()
    .then(() => console.log('Base de datos sincronizada correctamente'))
    .catch(err => console.error('Error al sincronizar la base de datos:', err));

// 📌 CRUD para Clientes
app.get('/clientes', async (req, res) => {
    const clientes = await cliente.findAll();
    res.json(clientes);
});

app.post('/clientes', async (req, res) => {
    const nuevoCliente = await cliente.create(req.body);
    res.json(nuevoCliente);
});

app.put('/clientes/:id', async (req, res) => {
    const clienteExistente = await cliente.findByPk(req.params.id);
    if (clienteExistente) {
        await clienteExistente.update(req.body);
        res.json(clienteExistente);
    } else {
        res.status(404).send('Cliente no encontrado');
    }
});

app.delete('/clientes/:id', async (req, res) => {
    const eliminado = await cliente.destroy({ where: { id: req.params.id } });
    eliminado ? res.send('Cliente eliminado') : res.status(404).send('Cliente no encontrado');
});

// 📌 CRUD para Proveedores
app.get('/proveedores', async (req, res) => {
    const listaProveedores = await proveedores.findAll();
    res.json(listaProveedores);
});

app.post('/proveedores', async (req, res) => {
    const nuevoProveedor = await proveedores.create(req.body);
    res.json(nuevoProveedor);
});

app.put('/proveedores/:id', async (req, res) => {
    const proveedorExistente = await proveedores.findByPk(req.params.id);
    if (proveedorExistente) {
        await proveedorExistente.update(req.body);
        res.json(proveedorExistente);
    } else {
        res.status(404).send('Proveedor no encontrado');
    }
});

app.delete('/proveedores/:id', async (req, res) => {
    const eliminado = await proveedores.destroy({ where: { id: req.params.id } });
    eliminado ? res.send('Proveedor eliminado') : res.status(404).send('Proveedor no encontrado');
});

// 📌 CRUD para Artículos
app.get('/articulos', async (req, res) => {
    const listaArticulos = await articulos.findAll();
    res.json(listaArticulos);
});

app.post('/articulos', async (req, res) => {
    const nuevoArticulo = await articulos.create(req.body);
    res.json(nuevoArticulo);
});

app.put('/articulos/:id', async (req, res) => {
    const articuloExistente = await articulos.findByPk(req.params.id);
    if (articuloExistente) {
        await articuloExistente.update(req.body);
        res.json(articuloExistente);
    } else {
        res.status(404).send('Artículo no encontrado');
    }
});

app.delete('/articulos/:id', async (req, res) => {
    const eliminado = await articulos.destroy({ where: { id: req.params.id } });
    eliminado ? res.send('Artículo eliminado') : res.status(404).send('Artículo no encontrado');
});

// 📌 CRUD para Empleados
app.get('/empleados', async (req, res) => {
    const listaEmpleados = await empleados.findAll();
    res.json(listaEmpleados);
});

app.post('/empleados', async (req, res) => {
    const nuevoEmpleado = await empleados.create(req.body);
    res.json(nuevoEmpleado);
});

app.put('/empleados/:id', async (req, res) => {
    const empleadoExistente = await empleados.findByPk(req.params.id);
    if (empleadoExistente) {
        await empleadoExistente.update(req.body);
        res.json(empleadoExistente);
    } else {
        res.status(404).send('Empleado no encontrado');
    }
});

app.delete('/empleados/:id', async (req, res) => {
    const eliminado = await empleados.destroy({ where: { id: req.params.id } });
    eliminado ? res.send('Empleado eliminado') : res.status(404).send('Empleado no encontrado');
});

// 📌 Iniciar servidor
app.listen(puerto, () => {
    console.log(`Servidor corriendo en http://localhost:${puerto}`);
});
