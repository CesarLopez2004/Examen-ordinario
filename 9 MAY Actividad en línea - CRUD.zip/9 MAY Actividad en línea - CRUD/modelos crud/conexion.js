const {Sequelize} = require('sequelize');
const sequelize = new Sequelize(
{
    dialect: 'sqlite',
    storage: './modelos.sqlite'
});

module.exports = sequelize;
